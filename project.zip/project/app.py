# flask_yamnet_inference.py
import os
import uuid
import numpy as np
import librosa
import soundfile as sf
from flask import Flask, render_template, request, redirect, url_for
import tensorflow as tf
import tensorflow_hub as hub
from tensorflow.keras.models import load_model
import pickle
from collections import Counter
import shutil

# ---------------- Flask Config ----------------
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('tmp_segments', exist_ok=True)

# ---------------- Model/Label Paths (update if needed) ----------------
CLASS_PATH = 'label_mapping.pkl'              # from training
CLASSIFIER_PATH = 'best_yamnet_classifier(1).h5' # training saved model
YAMNET_LOCAL_PATH = None  # set path string if you have YAMNet saved locally; else None to load from TF Hub

# ---------------- Load classifier & label mapping ----------------
classifier_model = load_model(CLASSIFIER_PATH, compile=False)
label_mapping = pickle.load(open(CLASS_PATH, 'rb'))  # {idx: label}
class_names = [label_mapping[i] for i in range(len(label_mapping))]

# ---------------- Load YAMNet ----------------
def load_yamnet(local_path=None):
    if local_path:
        print(f"Loading YAMNet locally from {local_path}")
        yamnet_model = hub.load(local_path)
    else:
        print("Loading YAMNet from TensorFlow Hub online")
        yamnet_model = hub.load('https://tfhub.dev/google/yamnet/1')
    return yamnet_model

yamnet_model = load_yamnet(YAMNET_LOCAL_PATH)

# ---------------- Utility: extract mean embedding for a waveform ----------------
def waveform_to_yamnet_embedding(waveform, sample_rate=16000):
    """
    Accepts a 1-D numpy waveform at sample_rate (should be 16000).
    Runs YAMNet and returns the mean embedding (1024 dim) for that waveform.
    """
    # Ensure float32 tensor
    waveform_tensor = tf.convert_to_tensor(waveform, dtype=tf.float32)
    # YAMNet returns (scores, embeddings, spectrogram), we only need embeddings
    _, embeddings, _ = yamnet_model(waveform_tensor)
    # embeddings shape: (num_frames, embedding_dim)
    emb_mean = tf.reduce_mean(embeddings, axis=0)
    return emb_mean.numpy()  # shape (1024,)

# ---------------- Audio segmentation (match training split behavior) ----------------
def split_audio_to_segments(file_path, segment_duration=5.0, target_sr=16000):
    """
    Loads file (any sr), resamples to target_sr, splits into segment_duration-second segments.
    Returns list of numpy arrays (float32) each length target_sr*segment_duration.
    """
    y, sr = librosa.load(file_path, sr=None, mono=True)
    if sr != target_sr:
        y = librosa.resample(y, orig_sr=sr, target_sr=target_sr)
        sr = target_sr

    segment_samples = int(segment_duration * sr)
    total_samples = len(y)
    segments = []
    # split into contiguous non-overlapping segments
    for start in range(0, total_samples, segment_samples):
        end = start + segment_samples
        seg = y[start:end]
        # pad last segment if shorter
        if len(seg) < segment_samples:
            seg = np.pad(seg, (0, segment_samples - len(seg)), mode='constant')
        segments.append(seg.astype(np.float32))
    return segments, sr

# ---------------- Flask routes ----------------
@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    confidence_table = None
    audio_filename = None
    segment_preds = []

    if request.method == 'POST':
        file = request.files.get('file')
        if not file or file.filename == '':
            return redirect(request.url)

        # Save uploaded file
        audio_filename = f"{uuid.uuid4().hex}_{file.filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], audio_filename)
        file.save(file_path)

        # Split audio into 5s segments and resample to 16k (YAMNet)
        segments, sr = split_audio_to_segments(file_path, segment_duration=5.0, target_sr=16000)

        # For each segment: extract YAMNet mean embedding and predict
        segment_embeddings = []
        for seg in segments:
            emb = waveform_to_yamnet_embedding(seg, sample_rate=16000)
            segment_embeddings.append(emb)
        X_emb = np.stack(segment_embeddings)  # shape (n_segments, 1024)

        # Classifier expects floats; ensure same dtype/shape as training
        preds = classifier_model.predict(X_emb)  # shape (n_segments, n_classes)
        pred_labels = np.argmax(preds, axis=1)
        pred_classes = [label_mapping[int(lbl)] for lbl in pred_labels]

        # Aggregate segment predictions (majority vote)
        counts = Counter(pred_classes)
        final_class = counts.most_common(1)[0][0]

        # Mean confidence per class across segments (as percentage)
        mean_confidences = {label_mapping[i]: float(np.mean(preds[:, i]) * 100.0) for i in range(preds.shape[1])}
        confidence_table = {k: f"{v:.2f}%" for k, v in mean_confidences.items()}

        prediction = f"Predicted Animal: {final_class} (based on {len(segments)} segments)"

        # Optionally remove uploaded file to save space
        # os.remove(file_path)

    return render_template('index.html',
                           prediction=prediction,
                           confidence_table=confidence_table,
                           audio_filename=audio_filename)


if __name__ == '__main__':
    # reproducibility seeds (optional)
    np.random.seed(42)
    tf.random.set_seed(42)
    app.run(debug=True, host='0.0.0.0', port=5001)
